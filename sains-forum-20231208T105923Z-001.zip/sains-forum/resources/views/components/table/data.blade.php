<td {{ $attributes->merge(['class' => 'px-6 py-4 text-gray-500 text-sm']) }}>
    {{ $slot }}
</td>
